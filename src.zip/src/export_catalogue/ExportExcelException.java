package export_catalogue;

public class ExportExcelException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3915606223384506841L;

	public ExportExcelException(String message) {
		super(message);
	}
}
