package dcf_webservice;

import catalogue_object.Catalogue;
import thread_listener.ThreadFinishedListener;

/**
 * Thread which is used to make reserve/unreserve operations
 * through the dcf web service. The operations are performed
 * in background.
 * @author avonva
 *
 */
public class ReserveThread extends Thread {

	// reserve client
	private Reserve reserve;
	
	// listener called when the thread finished the operation
	private ThreadFinishedListener doneListener;
	
	private Catalogue catalogue;
	private ReserveLevel reserveLevel;
	private String reserveDescription;
	private DcfResponse response;

	/**
	 * Initialize the information needed to perform a reserve
	 * operation
	 * @param catalogue
	 * @param reserveLevel
	 * @param reserveDescription
	 */
	public ReserveThread( Catalogue catalogue, ReserveLevel reserveLevel, String reserveDescription ) {
		
		// instantiate the reserve soap action
		this.reserve = new Reserve();
		
		// copy parameters
		this.catalogue = catalogue;
		this.reserveLevel = reserveLevel;
		this.reserveDescription = reserveDescription;
	}
	
	@Override
	public void run() {
		
		// reserve the catalogue and save the response
		this.response = reserve.reserve( catalogue, 
				reserveLevel, reserveDescription );
		
		// process the dcf response
		processResponse ( response );
		
		// call the listener if it was set
		if ( doneListener != null )
			doneListener.done( this );
	}
	
	/**
	 * Get the {@linkplain DcfResponse} reserve response
	 * @return
	 */
	public DcfResponse getResponse() {
		return response;
	}
	
	/**
	 * Process the response of the dcf
	 * @param response
	 */
	private void processResponse ( DcfResponse response ) {
		
		// go on only if ok response
		if ( response != DcfResponse.OK )
			return;
		
		// set the catalogue as (un)reserved at the selected level
		if ( reserveLevel.greaterThan( ReserveLevel.NONE ) )
			this.catalogue.reserve ( reserveLevel );
		else
			this.catalogue.unreserve ();
	}
	
	/**
	 * Add listener which is called when the thread finished the
	 * run operation
	 * @param doneListener
	 */
	public void addDoneListener(ThreadFinishedListener doneListener) {
		this.doneListener = doneListener;
	}
}
