package dcf_webservice;

import java.util.Base64;

import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

import org.w3c.dom.Document;

import catalogue_object.Catalogue;

/**
 * Class used to reserve/unreserve catalogues through the dcf web service.
 * @author avonva
 *
 */
public class Reserve extends SOAPAction {

	// namespace used in the ping xml message
	private static final String RESERVE_NAMESPACE = "http://ws.catalog.dc.efsa.europa.eu/";

	// web service link of the ping service
	//private static final String RESERVE_URL = "https://dcf-cms.efsa.europa.eu/catalogues";
	private static final String RESERVE_URL = "https://dcf-01.efsa.test/dc-catalog-public-ws/catalogues/?wsdl";

	// the catalogue we want to reserve/unreserve
	private Catalogue catalogue;
	
	// the reserve level we want to apply to the catalogue
	private ReserveLevel reserveLevel;
	
	// the description of why we are reserving/unreserving
	private String reserveDescription;
	
	/**
	 * Constructor to initialize the url and namespace for the
	 * reserve operation
	 */
	public Reserve() {
		super ( RESERVE_URL, RESERVE_NAMESPACE );
	}
	
	/**
	 * Reserve a catalogue with a major or minor reserve operation or unreserve it. 
	 * An additional description on why we reserve the catalogue is mandatory.
	 * Set reserve level to None to unreserve the catalogue.
	 * @param catalogue the catalogue we want to (un)reserve
	 * @param reserveLevel the reserve level we want to set (none, minor, major)
	 * @param reserveDescription a description of why we are (un)reserving
	 * @return the {@linkplain DcfResponse} enum, if all went ok then it returns OK, 
	 * if the operation failed it returns NO, if the connection with the DCF failed 
	 * or some errors occur it returns ERROR
	 */
	public DcfResponse reserve( Catalogue catalogue, ReserveLevel reserveLevel, 
			String reserveDescription ) {
		
		this.catalogue = catalogue;
		this.reserveLevel = reserveLevel;
		this.reserveDescription = reserveDescription;
		
		// log
		switch( reserveLevel ) {
		case NONE:
			System.out.println ( "Unreserving catalogue " + catalogue );
			break;
		case MINOR:
		case MAJOR:
			System.out.println ( "Reserving catalogue " + catalogue + " at level " + reserveLevel );
			break;
		default:
			break;
		}

		
		// default response
		DcfResponse response = DcfResponse.ERROR;
		
		// make the reserve operation
		// and get the dcf response
		try {
			
			// get the log response
			response = (DcfResponse) makeRequest();

		} catch (SOAPException e) {
			e.printStackTrace();
		}
		
		// return the response
		return response;
	}

	/**
	 * Create the reserve request message
	 */
	@Override
	public SOAPMessage createRequest(SOAPConnection con) throws SOAPException {

		// create the standard structure and get the message
		SOAPMessage soapMsg = createTemplateSOAPMessage ( "ws" );
		
		// get the body of the message
		SOAPBody soapBody = soapMsg.getSOAPPart().getEnvelope().getBody();

		// upload catalogue file node
		SOAPElement upload = soapBody.addChildElement( "UploadCatalogueFile", "ws" );
		
		// file data node (child of upload cf)
		SOAPElement fileData = upload.addChildElement( "fileData" );
		
		// add attachment to the request into the node <rowData>
		// using the right message for the related reserve operation
		String attachmentData = UploadMessages.getReserveMessage(
				catalogue.getCode(), reserveLevel, reserveDescription );
		
		// encoding attachment with base 64
		byte[] encodedBytes = Base64.getEncoder().encode( attachmentData.getBytes() );
		
		// row data node (child of file data)
		SOAPElement rowData = fileData.addChildElement( "rowData" );
		rowData.setValue( new String(encodedBytes) );
		
		// save the changes in the message and return it
		soapMsg.saveChanges();

		return soapMsg;
	}

	/**
	 * Process the response of the dcf, we check if everything went
	 * using the log which is returned in the response message. In particular,
	 * the log code is given. We can export the log using another web service
	 * and setting the log code as parameter.
	 * @return {@linkplain DcfResponse} enum, which shows if the request was
	 * successful or if there were errors.
	 */
	@Override
	public Object processResponse(SOAPMessage soapResponse) throws SOAPException {

		// search the log code in the soap message
		LogCodeFinder finder = new LogCodeFinder( soapResponse );

		// cache the log code (used in the retry function)
		String logCode = finder.getLogCode();
		
		// if errors the log code is not returned
		if ( logCode == null ) {
			System.err.println ( "Cannot find the log code in the soap response" );
			return DcfResponse.ERROR;
		}
		
		System.out.println ( "Found reserve log code " + logCode );
		
		// get the response and return it
		return getLogResponse ( logCode );
	}
	
	
	/**
	 * Get the response contained in the Log
	 * identified by the logCode
	 * @param logCode the code of the log to download and analyze
	 * @return the {@linkplain DcfResponse} response of the log
	 */
	private DcfResponse getLogResponse ( String logCode ) {
		
		int attempts = 100;
		long interAttemptsTime = 1000; // 1 second
		long retryTime = 300000;       // 5 minutes
		
		// get the log from the dcf
		Document log = getLog( logCode, attempts, 
				interAttemptsTime, retryTime );

		// analyze the log to get the macroOperationResult
		LogParser parser = new LogParser ( log );

		// return ok if correct operation
		if ( parser.isOperationCorrect() ) {
			System.out.println ( "(Un)reserve successfully completed" );
			return DcfResponse.OK;
		}
		else {
			System.out.println ( "(Un)reserve failed - the dcf rejected the operation" );
			return DcfResponse.NO;
		}
	}
	
	/**
	 * Get a log from the Dcf. Since it is possible that 
	 * the log is not immediately created by the Dcf, we
	 * try to get it several times (i.e. attempts parameter)
	 * @param logCode the code of the log we want to download
	 * @param attempts the maximum number of attempts
	 * @param interAttemptsTime the waiting time in milliseconds 
	 * between one attempt and the other.
	 * @param retryTime the waiting time in milliseconds which
	 * is waited to retry the reserve after all attempts failed
	 * @return the log in a {@linkplain Document} format
	 * since the log is an xml file.
	 */
	private Document getLog( String logCode, int attempts, 
			long interAttemptsTime, long retryTime ) {

		// try different times to get the dcf log
		// since it is not created immediately
		Document log = null;

		// do until the log is found
		while ( log == null ) {

			// try several times to get the log from the dcf
			for ( int i = 0; i < attempts; i++ ) {

				// ask for the log to the dcf
				ExportCatalogueFile export = new ExportCatalogueFile();

				// get the log document
				log = export.exportLog( logCode );

				// if log found break, otherwise retry
				if ( log != null ) {
					break;
				}

				// wait one second
				try {
					Thread.sleep( interAttemptsTime );
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				System.err.println ( "Log not found, retrying attempt n� " 
						+ (i+1) + "/" + attempts );
			}

			// if no log (i.e. no attachment was added to the response)
			// in the allowed attempts, wait tryTime before retrying
			// another batch of attempts
			if ( log == null ) {

				System.err.println ( "The Log is still missing after "
						+ attempts
						+ " attempts. Waiting " 
						+ ( retryTime / 1000 )
						+ " seconds to restart " );

				// wait
				try {
					Thread.sleep( retryTime );
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		
		return log;
	}
}
