package dcf_webservice;

/**
 *  enum to model the types of response related to a reserve operation
 *  Values:
 *  OK: all ok
 *  NO: the dcf received the request but is unable to accomplish 
 *  it (as if we want to reserve an already reserved catalogue)
 *  ERROR: operation failed due to connection problems or similar
 * @author avonva
 *
 */
public enum DcfResponse {
	OK,     // all ok

	NO,     // the dcf received the request but is unable to accomplish 
	        // it (as if we want to reserve an already reserved catalogue)
	
	ERROR   // operation failed due to connection problems or similar
}
