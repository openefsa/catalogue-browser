package ui_main_panel;

import java.util.Observable;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;

import messages.Messages;

/**
 * Class used to create the UI for a visualization filter.
 * In particular, we use this UI to create a filter in the
 * main tree of the browser, to hide deprecated terms or
 * not reportable terms.
 * @author avonva
 *
 */
public class TermFilter extends Observable {

	private Composite parent;
	private Button hideDeprecated;
	private Button hideNotInUse;
	
	/**
	 * Initialize the term filter
	 * @param parent
	 */
	public TermFilter( Composite parent ) {
		this.parent = parent;
	}
	
	/**
	 * Display the term filter
	 * @param parent
	 */
	public void display () {
		
		// label which says to choose view options
		Label applicabilityTitle = new Label( parent , SWT.NONE );
		applicabilityTitle.setText( Messages.getString("Browser.ViewTerms") );

		// switch between seeing and not seeing deprecated terms
		hideDeprecated = new Button( parent , SWT.CHECK );
		hideDeprecated.setSelection( false );
		hideDeprecated.setEnabled( false );
		hideDeprecated.setText( Messages.getString("Browser.HideDeprecatedTermsButton") );

		hideDeprecated.addSelectionListener( new SelectionAdapter() {
			@Override
			public void widgetSelected ( SelectionEvent e ) {
				setChanged();
				notifyObservers();
			}
		} );


		// switch between seeing and not seeing reportable terms
		hideNotInUse = new Button( parent , SWT.CHECK );
		hideNotInUse.setSelection( false );
		hideNotInUse.setEnabled( false );
		hideNotInUse.setText( Messages.getString("Browser.HideNonReportableTermsButton") );

		hideNotInUse.addSelectionListener( new SelectionAdapter() {
			@Override
			public void widgetSelected ( SelectionEvent e ) {
				setChanged();
				notifyObservers();
			}
		} );
	}
	
	/**
	 * Enable/disable filters
	 * @param enabled
	 */
	public void setEnabled( boolean enabled ) {
		hideDeprecated.setEnabled( enabled );
		hideNotInUse.setEnabled( enabled );
	}
	
	/**
	 * Get if we are hiding the deprecated terms
	 * @return
	 */
	public boolean isHidingDeprecated() {
		return hideDeprecated.getSelection();
	}
	
	/**
	 * Get if we are hiding not reportable terms
	 * @return
	 */
	public boolean isHidingNotReportable() {
		return hideNotInUse.getSelection();
	}
}
