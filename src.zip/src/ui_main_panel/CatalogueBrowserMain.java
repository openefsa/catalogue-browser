package ui_main_panel;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import business_rules.WarningUtil;
import catalogue_browser_dao.DatabaseManager;
import term_code_generator.CodeGenerator;
import utilities.GlobalUtil;

public class CatalogueBrowserMain {

	/**
	 * Read the application properties from the xml file
	 * @return
	 */
	private static Properties getApplicationProperties() {
		
		Properties properties = null;

		try {
			properties = new Properties();

			// fileStream from default properties xml file
			FileInputStream in = new FileInputStream( GlobalUtil.appPropertiesFile );
			properties.loadFromXML( in );

			in.close();
		}
		catch ( IOException e ) {
			e.printStackTrace();
		}
		
		return properties;
	}
	
	/**
	 * Get the application name reading it from
	 * the application properties object
	 * @param properties properties from which reading the application name
	 * @return
	 */
	private static String getApplicationName( Properties properties ) {
		
		// empty name if no properties found
		if ( properties == null )
			return "";
		
		return properties.getProperty( "Application.Name" );
	}
	
	/**
	 * Main, catalogue browser entry point
	 * 
	 * @param args
	 */
	public static void main ( String[] args ) {

		// application start-up message. Usage of System.err used for red chars
		System.out.println( "Application Started " + System.currentTimeMillis() );

		// system separator
		System.out.println( "Reading OS file separator: " + System.getProperty( "file.separator" ) );

		// database path
		System.out.println( "Locating database path in: " + DatabaseManager.MAIN_CAT_DB_FOLDER );
		
		// set the application name
		Properties properties = getApplicationProperties();
		CodeGenerator.ApplicationName = getApplicationName( properties );
		
		// Files checks, create directories if they don't exist

		// if the user files directory does not exist create it
		if ( !GlobalUtil.fileExists( GlobalUtil.userFileDir ) ) {
			new File( GlobalUtil.userFileDir ).mkdir();
		}

		// if the business rules directory does not exist create it
		if ( !GlobalUtil.fileExists( GlobalUtil.businessRulesDir ) ) {
			new File( GlobalUtil.businessRulesDir ).mkdir();
		}

		// connect to the main database and start it
		DatabaseManager.startMainDB();

		// Here the program stars showing the graphical interface, 
		// so here we call a specific function
		// to use only warnings if needed
		if ( args.length > 0 ) {
			
			// argument checks
			if ( args.length != 2 ) {
				System.err.println( "Wrong number of arguments, please check! Remember that if you want \n"
						+ "to use the Foodex Browser as Warning Checker you have to provide two parameters,\n"
						+ "that is, the input file path (collection of codes to be analysed) and the output file path.\n"
						+ "Otherwise, if you want to open the Foodex Browser Interface, no argument has to be set.");
				return;
			}
			
			WarningUtil.performWarningChecksOnly( args );
			
			// exit from the program, we do not need anything else
			return;
		}
		
		// create the display and shell
		Display display = new Display();
		Shell shell = new Shell ( display );
		
		// initialize the browser user interface
		MainPanel browser = new MainPanel( shell );
		
		// TODO remove this
		MainPanel._FoodexBrowser = browser;

		// creates the main panel user interface
		browser.initGraphics();

		// show ui
		browser.shell.open();

		// Event loop
		while ( !shell.isDisposed() ) {
			if ( !display.readAndDispatch() )
				display.sleep();
		}

		display.dispose();

		// stop the database
		DatabaseManager.stopMainDB();
	}
}
