import java.util.ArrayList;

import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.Viewer;

public class ContentProviderTermAttribute implements IStructuredContentProvider {

	public void dispose ( ) {
		// Not implemented

	}

	public void inputChanged ( Viewer arg0 , Object arg1 , Object arg2 ) {
		// Not implemented

	}

	public Object[] getElements ( Object arg0 ) {
		ArrayList< TermAttribute > att = foodexDAO.SelectedTerm.getAllTermAttributes();
		return att.toArray();
	}

}
