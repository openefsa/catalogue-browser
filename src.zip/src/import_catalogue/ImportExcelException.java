package import_catalogue;

public class ImportExcelException extends Exception {

	private static final long serialVersionUID = -7718660116892165278L;

	public ImportExcelException(String message) {
		super(message);
	}
}
