package ui_progress_bar;
/**
 * this exception is launched when the user click on cancel button on the export
 * operation.
 * 
 * @author thomm
 * 
 */
public class StopException extends RuntimeException {

}
