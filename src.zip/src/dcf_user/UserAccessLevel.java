package dcf_user;

/**
 * The permission level of the user. Can be 
 * data provider (i.e. read only) or catalogue
 * manager (i.e. edit mode on).
 * @author avonva
 *
 */
public enum UserAccessLevel {
	DATA_PROVIDER,
	CATALOGUE_MANAGER;
}
