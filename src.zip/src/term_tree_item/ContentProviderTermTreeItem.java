package term_tree_item;
import java.util.ArrayList;

import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.Viewer;

import catalogue_object.Catalogue;
import catalogue_object.GlobalTerm;
import catalogue_object.Hierarchy;
import catalogue_object.Nameable;
import catalogue_object.Term;

/**
 * Class used for fill the tree view, thats implements ITreeContentProvider who
 * is an interface to content providers for tree structure oriented viewers
 * 
 * @author
 */
@Deprecated
public class ContentProviderTermTreeItem implements ITreeContentProvider {

	// current hierarchy
	private Catalogue catalogue;
	private Hierarchy hierarchy;

	// applicability flags of the tree, which terms should be visualized?
	private boolean hideDeprecated = false;
	private boolean hideNotUse = false;
	
	/**
	 * Initialize the content provider and make it awas
	 * @param catalogue
	 */
	public ContentProviderTermTreeItem( Catalogue catalogue ) {
		this.catalogue = catalogue;
	}
	
	/**
	 * Set the current hierarchy for the tree viewer
	 * @param hierarchy
	 */
	public void setCurrentHierarchy ( Hierarchy hierarchy ) {
		this.hierarchy = hierarchy;
	}

	/**
	 * Hide deprecated terms from the visualization
	 * @param hideDeprecated
	 */
	public void setHideDeprecated(boolean hideDeprecated) {
		this.hideDeprecated = hideDeprecated;
	}

	/**
	 * Hide not reportable terms from the
	 * visualization
	 * @param hideNotUse
	 */
	public void setHideNotUse(boolean hideNotUse) {
		this.hideNotUse = hideNotUse;
	}

	public void dispose ( ) {}

	public void inputChanged ( Viewer viewer , Object arg1 , Object arg2 ) {}

	/**
	 * Method that return children element of parent(arg0) selected from user.
	 * This method is called when it the contentProvider needs to create or
	 * display the child elements of the domain(arg0). Should answer an array of
	 * domain objects that represent the unfiltered children of parent.
	 * 
	 * @param arg0
	 *            is the parent element
	 */
	public Object[] getChildren ( Object arg0 ) {

		ArrayList<Nameable> elem = new ArrayList<>();

		if ( arg0 == null )
			return elem.toArray();;

		if ( arg0 instanceof GlobalTerm ) {

			// if we have root add global term: all terms
			if ( arg0 == GlobalTerm.Root ) {
				elem.add( GlobalTerm.AllTerms );
			}

			// if we have all terms we add global terms: all hierarchies and all facets
			else if ( arg0 == GlobalTerm.AllTerms ) {
				elem.add( GlobalTerm.AllHierarchies );
				elem.add( GlobalTerm.AllFacets );
			}

			// if we have allhierarchies we add all the
			// catalogue base hierarchies
			else if ( arg0 == GlobalTerm.AllHierarchies ) {

				// Here we add the BASE hierarchies
				for ( Hierarchy hierarchy : hierarchy.getCatalogue().getHierarchies() ) {
					if ( hierarchy.isHierarchy() ) {
						elem.add( hierarchy );
					}
				}
			}

			// if we have allfacets we add all the
			// catalogue facet hierarchies
			else if ( arg0 == GlobalTerm.AllFacets ) {

				// Here we add the FACET hierarchies
				for ( Hierarchy hierarchy : hierarchy.getCatalogue().getHierarchies() ) {
					if ( hierarchy.isFacet() ) {
						elem.add( hierarchy );
					}
				}
			}
		}

		// if we have a term we simply get its children
		if ( arg0 instanceof Term ) {

			// get all the children of the term
			ArrayList<Term> children = 
					((Term) arg0).getChildren( hierarchy, hideDeprecated, hideNotUse );

			elem.addAll( children );
		}

		// if we have a hierarchy we simply get all its terms
		// in the first level
		else if ( arg0 instanceof Hierarchy ) {

			// get the terms which are at the first level in the hierarchy
			ArrayList<Term> children = 
					((Hierarchy) arg0).getFirstLevelNodes( hideDeprecated, hideNotUse );

			elem.addAll( children );
		}

		return elem.toArray();
	}

	/**
	 * This method is used to obtain the root elements for the tree viewer. This
	 * method is invoked by calling the setInput method on tree viewer, should
	 * answer with the appropriate domain objects of the inputElement. In our
	 * case we retrieving first nodes domain object with
	 * foodexDAO.getFirstLevelNodes() method.
	 */
	public Object[] getElements ( Object arg0 ) {
		return getChildren( arg0 );
	}

	/**
	 * The getParent method is used to obtain the parent of the given
	 * element(arg0). The tree viewer calls its content provider�s getParent
	 * method when it needs to reveal collapsed domain objects programmatically
	 * and to set the expanded state of domain objects. This method should
	 * answer the parent of the domain object element.
	 */
	public Object getParent ( Object arg0 ) {

		Object parent = null;

		if ( arg0 instanceof Hierarchy ){

		}
		else if ( arg0 instanceof Term ) {
			parent = ((Term) arg0).getParent( hierarchy );
		}
		else if ( arg0 instanceof Nameable ) {
			parent = null;
		}
		return parent;
	}

	/**
	 * The hasChildren method is invoked by the tree viewer when it needs to
	 * know whether a given domain object has children. The tree viewer asks its
	 * content provider if the domain object represented by element has any
	 * children. This method is used by the tree viewer to determine whether or
	 * not a plus or minus should appear on the tree widget.
	 */
	public boolean hasChildren ( Object arg0 ) {

		boolean hasChildren = false;

		if ( arg0 instanceof Hierarchy ){
			hasChildren = !( (Hierarchy) arg0).getFirstLevelNodes( 
					hasChildren, hideNotUse ).isEmpty();
		}
		else if ( arg0 instanceof Term ) {
			hasChildren = ( (Term) arg0 ).hasChildren( hierarchy, hideDeprecated, hideNotUse );
		}
		else if ( arg0 instanceof Nameable ) {
			hasChildren = true;
		}
		return hasChildren;
	}
}
