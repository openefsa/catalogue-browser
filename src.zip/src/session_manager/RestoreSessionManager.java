package session_manager;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Properties;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;

import messages.Messages;
import ui_main_panel.MainPanel;
import utilities.GlobalUtil;

/**
 * This class provide Store and Restore functionality for the application.
 * 
 * @author thomm
 * 
 */
public class RestoreSessionManager {
	/* Constraints for Type storing preferences */
	public static String		DESCRIBE			= "D"; //$NON-NLS-1$
	public static String		ADD					= "A"; //$NON-NLS-1$
	public static String		USERPREF			= "USERPREF"; //$NON-NLS-1$
	public static String		SEARCHOPT			= "SEARCHOPT"; //$NON-NLS-1$
	public static String		PICKLIST			= "PICKLIST"; //$NON-NLS-1$
	public static String		DATABASEOPT			= "DATABASEOPT"; //$NON-NLS-1$
	
	/* Window dimension */
	private String				IS_MAXI				= "ism"; //$NON-NLS-1$
	private static final String	MAINW_WIDTH			= "mwW"; //$NON-NLS-1$
	private static final String	MAINW_HEIGHT		= "mwH"; //$NON-NLS-1$
	private static final String	MAINW_X				= "mwX"; //$NON-NLS-1$
	private static final String	MAINW_Y				= "mwY"; //$NON-NLS-1$
	/* Session storing */
	private static final String	DEFAULT_STRING		= "NULL"; //$NON-NLS-1$
	private static final int	DEFAULT_INT			= 0;
	/**
	 * Costante per Flag per determinare se la ricerca � globale oppure no,
	 * attenzione a localSearch e globalSearch Button in congiunzione a
	 * foodexDAO.SearchGlobally .
	 */
	private static final String	SEARCH_GLOBALLY		= "sg"; //$NON-NLS-1$
	/**
	 * Costante per i flags della sezione Search Option .
	 */
	private static final String	STATE_FLAG			= "sf"; //$NON-NLS-1$
	/**
	 * Costante per i flags della sezione Additional Search Field .
	 */
	private static final String	SEARCH_NAMES		= "sn"; //$NON-NLS-1$
	/**
	 * Costante per i flags radio button prima del combobox .
	 */
	private static final String	SELECTION			= "sel"; //$NON-NLS-1$
	/**
	 * Costante per i nomi nel selection combo box .
	 */
	private static final String	SELECTION_COMBO		= "selBox"; //$NON-NLS-1$
	/**
	 * Costante per i flags della selezione view terms.
	 */
	private static final String	APPLICABILITY_FLAG	= "aplf"; //$NON-NLS-1$
	/**
	 * Costante per termine selezionato dall'utente se esiste .
	 */
	private static final String	CODE				= "cod"; //$NON-NLS-1$
	/**
	 * private instance of foodexBrowser instance.
	 */
	private MainPanel		_foodexBrowser		= null;
	private Shell						_s;
	private WindowCloseListener	_closeListener;
	private String	_widthMW;
	private String	_heightMW;
	private String	_xMW;
	private String	_yMW;
	private String	_isMaxi;

	/*---------------------------------------------------------------------*/

	public RestoreSessionManager( MainPanel f ) {
		_foodexBrowser = f;
	}
	
	/*private String currentDir(){
		File file = new File(".");
		return file.getAbsolutePath();
	}*/
	
	/**
	 * Return the old size which was used before for the window specified by winType
	 * @param shellBounds
	 * @param winType
	 * @return
	 */
	public Rectangle getOldSize ( String winType ) {
		
		Rectangle _referenceSize = null;
		try {
			_referenceSize = this.getStoredWinSize( winType );
		} catch ( FileNotFoundException e1 ) {
			e1.printStackTrace();
		} catch ( IOException e1 ) {
			e1.printStackTrace();
		}
		return _referenceSize;
	}
	/**
	 * Retrieve the properties stored into the system.
	 * 
	 * @return the preferences stored into the system or creates new one.
	 * @throws IOException 
	 */
	private InputStream getInPrefsFromSys ( )  {
		//String path = currentDir().substring( 0, currentDir().length()-1 )+"user-preferences.properties";
		String path = GlobalUtil.restoreSessionWindowFile;
		InputStream is = null;
		try {
			is = new FileInputStream(path);
			return is;
		}catch ( FileNotFoundException e ) {
			File file = new File( GlobalUtil.restoreSessionWindowFile );
			if (!file.exists())
				try {
					file.createNewFile();
					is = new FileInputStream( file ); 
				} catch ( IOException e1 ) {
					e1.printStackTrace();
				}
			else
				System.err.println("File Exists"); //$NON-NLS-1$
			e.printStackTrace();
		} 
		return is;
	}
	
	/**
	 * Store the properties into the system.
	 * 
	 * @return the preferences stored into the system or creates new one.
	 * @throws FileNotFoundException 
	 */
	private OutputStream getOuPrefsFromSys ( ) throws FileNotFoundException  {
		OutputStream ou = new  FileOutputStream( GlobalUtil.restoreSessionWindowFile );
		return ou;
	}
	
	/**
	 * This method restore the values of window dimensions previously stored.
	 */
	public void restoreWindowDimension ( Shell s ) {
		_s = s;
		try(InputStream in = getInPrefsFromSys()){
			Properties preferencesStored = new Properties();
			preferencesStored.load(in);
			String val = preferencesStored.getProperty( MAINW_WIDTH, String.valueOf( 0 ) );
			int width = Integer.valueOf( val );
			val = preferencesStored.getProperty( MAINW_HEIGHT, String.valueOf( 0 ) );
			int height = Integer.valueOf( val );
			val = preferencesStored.getProperty( MAINW_X, String.valueOf( 0 ) );
			int x = Integer.valueOf( val );
			val = preferencesStored.getProperty( MAINW_Y, String.valueOf( 0 ) );
			int y = Integer.valueOf( val );
//			System.err.println("WIDTH: " + width + " HEIGHT: " + height);
			if ( width == 0 || height == 0 ) {
				/* full screen window */
				s.setMaximized( true );//isStoredMaximized( "" )
			} else {
				s.setSize( width, height );
				s.setLocation( x, y );
//				 System.err.println("Not Maximized condition WIDTH: " + width
//				 + " HEIGHT: " + height);
			}
			in.close();
		} catch ( IOException e ) {
			e.printStackTrace();
			openDialog(Messages.getString("RestoreSessionManager.ErrorWindowTitle"), e.getMessage()); //$NON-NLS-1$
		}
		
	}
	
	/**
	 * This method store windows dimensions for future restore. The scope of
	 * this is the main window . The method check if the shell is maximized, if
	 * not will store all the information. (this)
	 * 
	 * @param sh
	 *            is the shell on which setup the listener on close event;
	 * 
	 */
	public void setStoreWindowDimension ( Shell sh ) {
		/* storing window dimension on the shell with a listener on close */
		_closeListener = new WindowCloseListener( sh , Messages.getString("RestoreSessionManager.WindowCloseListenerTitle") ); //$NON-NLS-1$
		sh.addListener( SWT.Close, _closeListener );
	}

	public void resetListener ( ) {
		if ( _closeListener != null )
			_s.removeListener( SWT.Close, _closeListener );
	}

	/**
	 * This method adds the resume session functionality for user. This asks to
	 * user if he want store session information for future session with a
	 * message on the screen.
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	public void askResumeSessionWindow (Properties prefs ) throws FileNotFoundException, IOException {
		int style = SWT.APPLICATION_MODAL | SWT.YES | SWT.NO;
		MessageBox messageBox = new MessageBox( _foodexBrowser.shell , style );
		messageBox.setText( Messages.getString("RestoreSessionManager.CloseAppTitle") ); //$NON-NLS-1$
		messageBox.setMessage( Messages.getString("RestoreSessionManager.CloseAppMessage") ); //$NON-NLS-1$
		int buttonID = messageBox.open();
		storeUserInformation( buttonID , prefs );
	}

	/**
	 * This method Store User Information for future reuse; Pay attention that
	 * foodexDAO .SelectedStateFlags=foodexDAO.StateFlags .
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	private void storeUserInformation ( int buttonID ,Properties prefs ) throws IOException  {
		if ( buttonID == SWT.YES ) {
			/* user has clicked to yes */
			//prefs.setProperty( SEARCH_GLOBALLY, String.valueOf( foodexDAO.SearchGlobally) );
			//System.err.println( "storing search globally: " + foodexDAO.SearchGlobally ); //$NON-NLS-1$

		//	if ( foodexDAO.SelectedStateFlags != null ) {
				/* search option; storing the ID of stateflags. */
			//	storeALSPInto( foodexDAO.SelectedStateFlags, prefs, STATE_FLAG );
			//}
			//if ( foodexDAO.SelectedSearchNames != null ) {
				/* additional search field */
			//	storeALSPInto( foodexDAO.SelectedSearchNames, prefs, SEARCH_NAMES );
			//}

			/* choice of Hierarchy-Facet RadioButton */
			//prefs.setProperty( SELECTION, String.valueOf( _foodexBrowser.getHierarchyChoice() ) );

			//if ( foodexDAO.SelectedHierarchy != null ) {
				/* combobox selection */
//				System.err.println( "storing hierarchy: " + foodexDAO.SelectedHierarchy.getName() );
				//prefs.setProperty( SELECTION_COMBO, String.valueOf(  _foodexBrowser.getPositionSelectedCB() ) );
			//}

			//if ( foodexDAO.SelectedApplicabilityFlags != null ) {
				/* view term saving */
				//ArrayList<SimpleProperty> a = foodexDAO.SelectedApplicabilityFlags;
			//	storeALSPInto( foodexDAO.SelectedApplicabilityFlags, prefs, APPLICABILITY_FLAG );
			//}

			//if ( foodexDAO.SelectedTerm != null ) {
				/* selected term on tree selection */
			//	System.err.println( foodexDAO.SelectedTerm.getCode() );
			//	prefs.setProperty( CODE, foodexDAO.SelectedTerm.getCode() );
			//}
		} else {/* user has clicked to no */
			
			prefs.setProperty( SEARCH_GLOBALLY, String.valueOf( false ) );
			prefs.setProperty( STATE_FLAG, DEFAULT_STRING );
			prefs.setProperty( SEARCH_NAMES, DEFAULT_STRING );
			prefs.setProperty( SELECTION, String.valueOf( true ));
			prefs.setProperty( SELECTION_COMBO, String.valueOf( DEFAULT_INT - 1 ));
			prefs.setProperty( APPLICABILITY_FLAG, DEFAULT_STRING );
			prefs.setProperty( CODE, DEFAULT_STRING );
		}
	}
	
	/**
	 * this method store the proprerties .
	 * @param preferencesStored
	 * @throws IOException
	 */
	private void storeProperties ( Properties preferencesStored ) throws IOException {
		try(OutputStream out = getOuPrefsFromSys() ){
			preferencesStored.store( out, ""); //$NON-NLS-1$
		}
	}
	
	/**
	 * This method retrieve user session information and restore GUI.
	 */
	public void restoreUserInformation ( ) {
		try(InputStream is = getInPrefsFromSys() ) {
			Properties preferencesStored = new Properties();
			preferencesStored.load(is);
			/* restoring global search */
			String gloSearch = preferencesStored.getProperty( SEARCH_GLOBALLY, String.valueOf( false ) );
			if ( gloSearch.equals( "false" ) ) { //$NON-NLS-1$
				//_foodexBrowser.setGlobalSearch( false );
				// System.err.println("restored global search: " + gloSearch);
			}//else
				//_foodexBrowser.setGlobalSearch( true );
			
			/* restoring flags state flag */
			String sf = preferencesStored.getProperty( STATE_FLAG, DEFAULT_STRING );
			if ( !sf.equals( DEFAULT_STRING ) && sf != null ) {
				//ArrayList< Integer > idSf = parseStoredPreference( sf );
				//setChecked( _foodexBrowser.listStateFlag, idSf, foodexDAO.StateFlags );
				//compact( _foodexBrowser.listStateFlag, foodexDAO.SelectedStateFlags );
				System.err.println( "restored stateflag: " + sf ); //$NON-NLS-1$
			}/* else, the values are yet on default(all checked). */

			/* restoring flags search names */
			String sn = preferencesStored.getProperty( SEARCH_NAMES, DEFAULT_STRING );
			if ( !sn.equals( DEFAULT_STRING ) && sn != null ) {
				//ArrayList< Integer > idSn = parseStoredPreference( sn );
				// TODO? a cosa serve?
				//setChecked( _foodexBrowser.listSearchNames, idSn, foodexDAO.SearchNames );
				//compact( _foodexBrowser.listSearchNames, foodexDAO.SelectedSearchNames );
				System.err.println( "restored searchnames: " + sn ); //$NON-NLS-1$
			}/* else, the values are yet on default(all checked). */

			/* restroring complete values of the combo box(radiobutton and combobox) */
			/* default value is true. */
			String chooseHier = preferencesStored.getProperty(  SELECTION, "true" ); //$NON-NLS-1$
			if ( chooseHier.equals( "false" ) ) { //$NON-NLS-1$
				//_foodexBrowser.selectHierarchyRadioButt( false );
				System.err.println( "restored choice hierarchy: " + chooseHier ); //$NON-NLS-1$
			}/* else, the values are yet on default(all checked). */

			/* restoring position combobox */
			String positionCombo =  preferencesStored.getProperty( SELECTION_COMBO, String.valueOf(DEFAULT_INT - 1) );
			Integer posCB = Integer.valueOf( positionCombo );
			if ( posCB != DEFAULT_INT - 1 && posCB != null ) {
				//_foodexBrowser.updateComboBox( posCB );
				//_foodexBrowser.updateSelHierarchy( (IStructuredSelection) _foodexBrowser.selectionCombo
					//	.getSelection() );
				System.err.println( "restored positon combobox: " + posCB ); //$NON-NLS-1$
			}/* else, the values are yet on default(all checked). */

			/* restoring applicability flags, view terms top right */
			String af = preferencesStored.getProperty( APPLICABILITY_FLAG, DEFAULT_STRING );
			if ( !af.equals( DEFAULT_STRING ) && af != null ) {
				ArrayList< Integer > idAf = parseStoredPreference( af );
				//_foodexBrowser.updateFlagViewTerms( idAf );
				System.err.println( "restored applicability flag: " + af ); //$NON-NLS-1$
			}

			/* restoring selection on the tree */
			String code = preferencesStored.getProperty( CODE, DEFAULT_STRING );
			if ( !code.equals( DEFAULT_STRING ) && code != null ) {
				System.err.println( "CODICE: " + code ); //$NON-NLS-1$
				//_foodexBrowser.updateTreeViewer( code );
			}
			is.close();
		} catch ( FileNotFoundException e ) {
			e.printStackTrace();
		} catch ( IOException e ) {
			e.printStackTrace();
		}
		// System.out.println("ABS PATH: "+preferencesStored.absolutePath());
	}

	/**
	 * This method store an ArrayList of SimpleProperty into a string in correct
	 * way, storing the ID of object and separating each object with '|'. The
	 * key of storing is the parameter key.
	 * 
	 * @param alsp
	 *            array to store;
	 * @param pstored
	 *            preferences where store;
	 * @param key
	 *            key value of the storing.
	 */
	/*private void storeALSPInto ( ArrayList< SimpleProperty > alsp , Properties pstored , String key ) {
		String s = ""; //$NON-NLS-1$
		for ( int j = 0 ; j < alsp.size() ; j++ ) {
			s += "" + alsp.get( j ).getId() + "|"; //$NON-NLS-1$ //$NON-NLS-2$
		}
		System.err.println( "storing " + key + ": " + s ); //$NON-NLS-1$ //$NON-NLS-2$
		pstored.setProperty( key, s );
	}*/

	/**
	 * This method set checked the content of cbtv, in function of the
	 * ArrayList<SimpleProperty> ali stored correctly and alsp .
	 * 
	 * @param cbtv
	 *            GUI object for retrieve object;
	 * @param ali
	 * @param alsp
	 */
/*
	private void setChecked ( CheckboxTableViewer cbtv , ArrayList< Integer > ali ,
			ArrayList< SimpleProperty > alsp ) {
		Integer valueOfID = 0;
		for ( int e = 0 ; e < alsp.size() ; e++ ) {
			valueOfID = Integer.valueOf( alsp.get( e ).getId() );
			cbtv.setChecked( alsp.get( e ), ( ali.indexOf( valueOfID ) != -1 ) );
			// System.err.println(""+e+""+(ali.indexOf( valueOfID )!=-1));
			// System.err.println("stateflags: "+e+alsp.get(e).getName());
		}
	}
*/
	/**
	 * This method compact the ArrayList of Simple Property in function of
	 * content selected on cbtv.
	 * 
	 * @param cbtv
	 *            GUI object for retrieve object;
	 * @param alsp
	 *            array to compact;
	 */
	/*
	private void compact ( CheckboxTableViewer cbtv , ArrayList< SimpleProperty > alsp ) {
		Object[] checkElems = cbtv.getCheckedElements();
		alsp.clear();
		for ( int e = 0 ; e < checkElems.length ; e++ ) {
			alsp.add( (SimpleProperty) checkElems[e] );
		}
	}*/

	/**
	 * This method parse preferences string into ArrayList<Integer>, which all
	 * value are Integer and separed with character '|'
	 * 
	 * @param stringToParse
	 * @return
	 */
	private ArrayList< Integer > parseStoredPreference ( String stringToParse ) {
		ArrayList< Integer > idSf = new ArrayList< Integer >();
		String[] splittedstring = stringToParse.split( "\\|" ); //$NON-NLS-1$
		for ( int j = 0 ; j < splittedstring.length ; j++ ) {
			// System.err.println("split string : "+ splittedstring[j] );
			idSf.add( new Integer( Integer.valueOf( splittedstring[j] ) ) );
		}
		return idSf;
	}

	/**
	 * This method setup the shell for storing description window dimension.
	 * 
	 * @param sh
	 */
	public void setStoreDescWinDim ( Shell shell ) {
		_closeListener = new WindowCloseListener( shell , DESCRIBE );
		shell.addListener( SWT.Close, _closeListener );
	}

	public void setStoreWinDim ( Shell shell, String type ) {
		shell.addListener( SWT.Close, new WindowCloseListener( shell , type ) );
	}
	/**
	 * This method sets Listener for saving size windows dimensions
	 * 
	 * @param shell
	 */
	public void setStoreAddWinDim ( Shell shell ) {
		shell.addListener( SWT.Close, new WindowCloseListener( shell , ADD ) );
	}

	/**
	 * This method sets Listener for saving size windows dimensions
	 * 
	 * @param shell
	 */
	public void setStoreUserPrefWinDim ( Shell shell ) {
		shell.addListener( SWT.Close, new WindowCloseListener( shell , USERPREF ) );
	}
	
	/**
	 * This method retrieve info from stored dimension user preference and
	 * return to its caller the rectangle with the info retrieved or null.
	 * 
	 * @return
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	public Rectangle getStoredWinSize ( String windowType ) throws FileNotFoundException, IOException {
		windowType = parseWindType( windowType );
		Rectangle result = null;
		InputStream is = null;
		try {
			is = getInPrefsFromSys() ;
			Properties preferencesStored = new Properties();
			preferencesStored.load( is );
			String val = preferencesStored.getProperty(  windowType + MAINW_WIDTH, String.valueOf( DEFAULT_INT ));
			Integer width = Integer.valueOf( val );
			val = preferencesStored.getProperty(  windowType + MAINW_HEIGHT, String.valueOf( DEFAULT_INT ));
			Integer height = Integer.valueOf( val );
			val = preferencesStored.getProperty(   windowType + MAINW_X, String.valueOf( DEFAULT_INT ));
			Integer x =  Integer.valueOf( val );
			val = preferencesStored.getProperty(   windowType + MAINW_Y, String.valueOf( DEFAULT_INT ));
			Integer y =  Integer.valueOf( val );
			System.out.println(windowType + MAINW_WIDTH + width);
			System.out.println(windowType + MAINW_HEIGHT+ height);
			System.out.println( windowType + MAINW_X+ x);
			System.out.println( windowType + MAINW_Y+y );
			if ( width != DEFAULT_INT && height != DEFAULT_INT ) {
				result = new Rectangle( x , y , width , height );
			}
			is.close();
		}finally{
			if (is != null)
				is.close();
		}

		return result;
	}

	/**
	 * This method confirm if the shell is stored maximized.
	 * 
	 * @param string
	 * @return
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	public boolean isStoredMaximized ( String windowType ) throws FileNotFoundException, IOException {
		String s = parseWindType( windowType );
		boolean ret = false;
		try(InputStream in = getInPrefsFromSys()){
			Properties preferencesStored = new Properties();
			preferencesStored.load( in );
			ret = Boolean.getBoolean( preferencesStored.getProperty( s + IS_MAXI, String.valueOf( true )) );
		}
		return ret;
	}

	/**
	 * This private method permits to retrieve type window, without duplicate
	 * the code;
	 * 
	 * @param windowType
	 *            String type of window ;
	 * 
	 * @return the true value of type of window
	 */
	private String parseWindType ( String windowType ) {
		windowType = windowType.toUpperCase();

		if ( windowType.equals( DESCRIBE ) )
			return DESCRIBE;
		else if ( windowType.equals( ADD ) )
			return ADD;
		else if ( windowType.equals( USERPREF ) )
			return USERPREF;
		else if ( windowType.equals( SEARCHOPT ) )
			return SEARCHOPT;
		else if ( windowType.equals( PICKLIST ) )
			return PICKLIST;
		else if ( windowType.equals( DATABASEOPT ) )
			return DATABASEOPT;
		else
			return ""; //$NON-NLS-1$
	}

	/**
	 * This inner class setup the listener close window which deals : store info
	 * dimension and mechanism for ask user if he want save the current info
	 * session(only if in default mode).
	 * 
	 * @author thomm
	 * 
	 */
	class WindowCloseListener implements Listener {

		private Shell	_s;
		private String	_mode;

		public WindowCloseListener( Shell s, String mode ) {
			_s = s;
			_mode = parseWindType( mode );
		}

		public void handleEvent ( Event event ) {
			try(InputStream in = getInPrefsFromSys()){
				if ( !_s.getMaximized() ) {
					Rectangle windowDims = _s.getBounds();
					setWindowState(String.valueOf( windowDims.width ), String.valueOf(windowDims.height), String.valueOf(windowDims.x),
							String.valueOf(windowDims.y), String.valueOf(false));
//					System.out.println("Storing : WIDTH="+windowDims.width +" HEIGHT="+windowDims.height+
//							" x="+windowDims.x+" y="+windowDims.y);
				} else {
//					System.err.println( "Maximized condition STORING" );
					setWindowState(String.valueOf( 0 ), String.valueOf(0), String.valueOf(0),
							String.valueOf(0), String.valueOf(true));
				}
				Properties prefs= new Properties();
				prefs.load(in);

				storeWindowState(prefs , _mode );
				
				if ( _mode.equals( "" ) ) //$NON-NLS-1$
						askResumeSessionWindow(prefs);
				storeProperties (prefs);
				in.close();
			} catch ( IOException e1 ) {
				e1.printStackTrace();
				openDialog(Messages.getString("RestoreSessionManager.ErrorWindowTitle2"), e1.getMessage()); //$NON-NLS-1$
			}
		}
	}

	private void storeWindowState ( Properties preferencesStored , String mode) {
		preferencesStored.setProperty( mode + MAINW_WIDTH, _widthMW);
		preferencesStored.setProperty( mode + MAINW_HEIGHT, _heightMW );
		preferencesStored.setProperty( mode + MAINW_X, _xMW  );
		preferencesStored.setProperty( mode + MAINW_Y, _yMW  );
		preferencesStored.setProperty( mode + IS_MAXI, _isMaxi  );
	}
	
	private void setWindowState ( String width, String height, String x , String y, String ismaxy) {
		_widthMW=width ;
		_heightMW=height ;
		_xMW  = x ;
		_yMW = y ;
		_isMaxi =ismaxy ;
	}
	
	public void openDialog ( String string , String message) {
		MessageBox mb = new MessageBox( _s , SWT.OK );
		mb.setText( string );
		mb.setMessage( message );
		mb.open();
	}
}