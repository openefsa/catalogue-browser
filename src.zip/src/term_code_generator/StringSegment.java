package term_code_generator;
public class StringSegment {

	public int	start;
	public int	length;

	public int getEnd ( ) {
		// TODO Auto-generated method stub
		return start + length;
	}

}
