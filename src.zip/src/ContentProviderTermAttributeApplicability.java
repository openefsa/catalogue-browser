import java.util.ArrayList;

import org.eclipse.jface.viewers.IContentProvider;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.Viewer;

public class ContentProviderTermAttributeApplicability implements ITreeContentProvider {

	public void dispose ( ) {

	}

	public void inputChanged ( Viewer arg0 , Object arg1 , Object arg2 ) {

	}

	public Object[] getChildren ( Object arg0 ) {
		System.err.println( "retrieving the root elements for constraints" );
		System.err.println( arg0 );
		ArrayList< TermElem > teChildren = null;
		if ( arg0 != null ) {
			TermElem te = (TermElem) arg0;
			if ( te.children != null ) {
				teChildren = te.children;
			}
		}
		if ( teChildren == null )
			teChildren = new ArrayList< TermElem >();
		return teChildren.toArray();
	}

	/*
	 * in this get element the list of the first nodes is passed and not a root
	 * element
	 */
	public Object[] getElements ( Object arg0 ) {
		System.err.println( "retrieving the root elements for constraints" );
		System.err.println( arg0 );
		ArrayList< TermElem > teChildren = null;
		if ( arg0 != null ) {
			teChildren = (ArrayList< TermElem >) arg0;
		}
		if ( teChildren == null )
			teChildren = new ArrayList< TermElem >();
		return teChildren.toArray();
	}

	public Object getParent ( Object arg0 ) {
		TermElem te = null;
		if ( arg0 != null ) {
			te = ( (TermElem) arg0 ).parent;
		}
		return te;

	}

	public boolean hasChildren ( Object arg0 ) {

		ArrayList< TermElem > teChildren = null;
		if ( arg0 != null ) {
			TermElem te = (TermElem) arg0;
			if ( te.children != null ) {
				teChildren = te.children;
			}
		}
		if ( teChildren == null )
			teChildren = new ArrayList< TermElem >();
		return teChildren.size() > 0 ? true : false;
	}

}
