package ui_search_bar;

/**
 * Listener called when a hierarchy is selected
 * and some actions are required.
 * @author avonva
 *
 */
public class HierarchyChangedListener {
	
	public void hierarchyChanged( HierarchyEvent event ) {
		
	}
}
