package ui_search_bar;

/**
 * Search listener, override this method to use it
 * @author avonva
 *
 */
public class SearchListener {
	public void searchPerformed ( SearchEvent event ) {
	}
}
