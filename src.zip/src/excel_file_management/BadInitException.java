package excel_file_management;
public class BadInitException extends Exception {

}
