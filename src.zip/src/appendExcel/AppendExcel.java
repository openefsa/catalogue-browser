package appendExcel;

/* the operation are regulated by the field operation
 * 
 * * INSERT (only if the term is not present)
 * * UPDATE (only if the term is present)
 * * INSERT_UPDATE (insert if the term is not present, update if the term is present )
 * * INSERT_LINK (insert if the term is not present, link if the term is present )
 * * LINK (only link the entries)
 * 
 * if the operation is not specified the operation performed is INSERT_LINK
 * 
 * The code are identified first by code and then by name
 * 
 * Facets cannot be managed through this procedure
 * 
 * Common names and scientific names are up to date
 * 
 * 
 */


public class AppendExcel {
	
}
