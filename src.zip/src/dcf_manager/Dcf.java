package dcf_manager;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.SOAPException;
import javax.xml.transform.TransformerException;

import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import catalogue_browser_dao.CatalogueDAO;
import catalogue_object.Catalogue;
import catalogue_object.Version;
import dcf_user.UserAccessLevel;
import dcf_webservice.ExportCatalogue;
import dcf_webservice.ExportCatalogueFile;
import dcf_webservice.GetCataloguesList;
import dcf_webservice.Ping;
import dcf_webservice.ReserveLevel;
import dcf_webservice.ReserveThread;
import dcf_webservice.UpdatesChecker;
import dcf_webservice.UserProfileChecker;
import import_catalogue.ImportActions;
import thread_listener.ThreadFinishedListener;
import ui_progress_bar.FormProgressBar;

/**
 * Class to model the DCF. Here we can download
 * catalogues and (TODO) perform web service operations.
 * @author avonva
 *
 */
public class Dcf {
	
	// progress bar
	private FormProgressBar progressBar;
	
	/**
	 * A list which contains all the published 
	 * dcf catalogues
	 */
	private static ArrayList < Catalogue > catalogues = null;

	/**
	 *  True if we are currently getting catalogue updates
	 *  false otherwise
	 */
	private static boolean gettingUpdates = false;

	/**
	 * True if the dcf is reserving 
	 * a catalogue, false otherwise
	 */
	private static boolean reserving = false;
	
	/**
	 * True if the dcf is unreserving 
	 * a catalogue, false otherwise
	 */
	private static boolean unreserving = false;
	
	/**
	 * Set if the application is reserving a catalogue or not
	 * @param reserving
	 */
	public static void setReserving(boolean reserving) {
		Dcf.reserving = reserving;
	}
	
	/**
	 * Is the application reserving a catalogue?
	 * @return
	 */
	public static boolean isReserving() {
		return reserving;
	}
	
	/**
	 * Is the application unreserving a catalogue?
	 * @return
	 */
	public static boolean isUnreserving() {
		return unreserving;
	}

	/**
	 * Get all the catalogues which can 
	 * be downloaded from the dcf
	 * @return
	 */
	public static ArrayList<Catalogue> getCatalogues() {
		return catalogues;
	}

	/**
	 * Get the codes of the catalogues which need to be updated or are new
	 * compared to the ones that I already have downloaded in my pc.
	 * 
	 * A list which contains all the catalogues 
	 * which can be downloaded compared to the ones we
	 * have already downloaded in our local machine. This
	 * means that this list contains all the catalogues we
	 * don't have and the catalogues which need an update
	 * compared to the version we have in our machine.
	 * @return
	 */
	public static ArrayList <Catalogue> getDownloadableCat () {
		
		// list of catalogues from which the user can select
		// we want them to be only the catalogues which have not been downloaded yet
		// or catalogues updates
		ArrayList <Catalogue> catalogueToShow = new ArrayList<>();

		if ( catalogues == null || catalogues.isEmpty() )
			return catalogueToShow;
		
		CatalogueDAO catDao = new CatalogueDAO();
		
		// get the catalogues which are currently 
		// present into the user database
		// at their last release status!
		ArrayList < Catalogue > myCatalogues = catDao.getLastReleaseCatalogues ();

		// for each DCF catalogue
		for ( Catalogue cat : catalogues ) {
			
			// if the catalogue is not contained in the my catalogues
			// we have found a catalogue which has not been downloaded yet
			// note we add it only if it is not deprecated
			// do not show cat users catalogue to users
			if ( myCatalogues.contains( cat ) || cat.isDeprecated() || 
					cat.isCatUsersCatalogue() )
				continue;
			
			catalogueToShow.add( cat );
		}
		
		
		// here we searches for catalogues updates
		for ( Catalogue myCat : myCatalogues ) {

			// if we already have the last release go on
			if ( myCat.isLastRelease() )
				continue;
			
			// get the catalogue which is the updated version of the
			// my cat catalogue (or null if no update is available)
			Catalogue updateCat = getLastPublishedRelease ( myCat );
			
			// if there is an update => add the catalogue to the list
			// we exclude the cat users catalogue since it is downloaded
			// automatically with the login process
			if ( updateCat != null && !updateCat.isCatUsersCatalogue() ) {
				catalogueToShow.add( updateCat );
			}
		}

		// sort catalogues by label and version
		Collections.sort( catalogueToShow );
		
		return catalogueToShow;
	}
	
	/**
	 * Is the application getting the catalogues updates
	 * from the dcf?
	 * @return
	 */
	public static boolean isGettingUpdates() {
		return gettingUpdates;
	}

	/**
	 * Are the catalogue meta data being downloaded now?
	 * @param gettingUpdates
	 */
	public static void setGettingUpdates(boolean gettingUpdates) {
		Dcf.gettingUpdates = gettingUpdates;
	}

	/**
	 * Get the last release of a catalogue
	 * @param catalogue
	 * @return
	 */
	public static Catalogue getLastPublishedRelease ( Catalogue catalogue ) {

		if ( catalogues == null ) {
			System.err.println( "No dcf catalogues found in the cache" );
			return null; 
		}

		// get the catalogue in the dcf list
		// using only its code
		int index = catalogues.indexOf( catalogue );

		// if not found
		if ( index == -1 )
			return null;

		return catalogues.get( index );
	}

	/**
	 * Refresh the catalogues of the dcf downloading their
	 * meta data. Refresh also the downloadable catalogues.
	 */
	public void refreshCatalogues() {
		
		// flag to say that we are getting the updates
		gettingUpdates = true;
		
		// get all the dcf catalogues and save them
		try {
			
			catalogues = new GetCataloguesList().getCataloguesList();
			
			// sort catalogues by label and version
			Collections.sort( catalogues );
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// we have finished to get updates
		gettingUpdates = false;
	}
	
	/**
	 * Set a progress bar which is called for
	 * webservices.
	 * @param progressBar
	 */
	public void setProgressBar ( FormProgressBar progressBar ) {
		this.progressBar = progressBar;
	}
	
	/**
	 * Make a ping to the dcf
	 * @return true if the dcf is responding correctly
	 */
	public boolean ping() {
		
		boolean check;
		
		try {
			check = (boolean) ( new Ping() ).makeRequest();
		} catch (SOAPException e) {
			e.printStackTrace();
			check = false;
		}
		
		return check;
	}
	
	/**
	 * Start the thread which checks the user access
	 * level (see {@link UserAccessLevel} ).
	 * @param doneListener {@link Listener } called when
	 * the thread has finished its work.
	 */
	public void setUserLevel( Listener doneListener ) {
		
		// set the access level of the user
		final UserProfileChecker userLevel = new UserProfileChecker();
		
		userLevel.addDoneListener( doneListener );
		
		userLevel.start();
	}
	
	/**
	 * Get the catalogues updates from the dcf. In particular,
	 * we download the all the published catalogues (only metadata)
	 * and refresh the dcf catalogues cache ( {@link Dcf#catalogues} )
	 * @param doneListener
	 */
	public void checkUpdates ( Listener doneListener ) {
		
		// start downloading the catalogues updates (meta data only)
		final UpdatesChecker catUpdates = new UpdatesChecker();
		
		// set the listener
		catUpdates.setUpdatesListener( doneListener );
		
		catUpdates.start();
	}
	
	/**
	 * Get the list of all the dcf catalogues (only published)
	 * @return array list of dcf published catalogues
	 */
	public ArrayList<Catalogue> getCataloguesList() {
		
		ArrayList<Catalogue> list = new ArrayList<>();
		
		// get the dcf catalogues
		GetCataloguesList catList = new GetCataloguesList();
		
		try {
			
			list = catList.getCataloguesList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return list;
	}
	
	/**
	 * Download a dcf catalogue into the local machine. The
	 * catalogue is downloaded in xml format.
	 * @param catalogue the catalogue we want to download
	 * @param filename the xml filename
	 * @return true if the export was successful
	 */
	public boolean exportCatalogue( Catalogue catalogue, String filename ) {
		
		// export the catalogue and save its attachment into an xml file
		ExportCatalogue export = new ExportCatalogue ( catalogue, filename );
		return export.exportCatalogue();
	}
	
	/**
	 * Export a log from the dcf given its code
	 * @param logCode the code of the log which needs to
	 * be downloaded
	 * @return a dom document which contains the log
	 */
	public Document exportLog ( String logCode ) {
		
		// ask for the log to the dcf
		ExportCatalogueFile export = new ExportCatalogueFile();

		// get the log document
		return export.exportLog( logCode );
	}

	/**
	 * Export the internal version of a catalogue into the selected
	 * filename. If no internal version is retrieved no action is
	 * performed.
	 * @param catalogueCode the code which identifies the catalogue
	 * we want to download
	 * @param filename the filename in which we want to store the
	 * last internal version of the catalogue
	 * @throws IOException
	 */
	public boolean exportCatalogueInternalVersion ( String catalogueCode, 
			String filename ) throws IOException {
		
		// ask for the log to the dcf
		ExportCatalogueFile export = new ExportCatalogueFile();

		// get the catalogue xml
		InputStream stream = export.exportCatInternalVersion( catalogueCode );
		
		// if not internal version ok, you can go on
		if ( stream == null ) {
			System.out.println ( "No internal version found for " + catalogueCode );
			return false;
		}

		// write the input stream into the file
		byte[] buffer = new byte[ stream.available() ];
		stream.read( buffer );

		// save the last internal version into a file
		// in order to possibly import it by the xml
		File targetFile = new File( filename );
		OutputStream outStream = new FileOutputStream( targetFile );
		outStream.write( buffer );
		outStream.close();
		
		return true;
	}
	
	/**
	 * Start the reserve operation for a catalogue. This method
	 * checks if 
	 * @param catalogue the catalogue we want to reserve
	 * @param level the reserve level we want
	 * @param description the reserve description
	 * @param listener listener called when the reserve operation finishes
	 */
	public ReserveLog reserve ( final Catalogue catalogue, 
			final ReserveLevel level, final String description, final ReserveStartedListener start,
			final ReserveFinishedListener listener ) {
		
		// check what we have to do before making the reserve request
		final ReserveLog response = reserveCheck( catalogue, level );
		
		switch ( response ) {
		case MINOR_FORBIDDEN:
		case ERROR:
			break;
			
			// if correct or unreserve
		case NOT_RESERVING:
		case CORRECT_VERSION:
			
			// notify that the reserve started
			start.start();
			
			startReserveThread ( catalogue, level, description, listener );
			break;
			
		case OLD_VERSION:
			
			// download the last internal version
			// and when the process is finished
			// reserve the NEW catalogue
			ImportActions imprt = new ImportActions();
			
			// set the progress bar if possible
			if ( progressBar != null )
				imprt.setProgressBar( progressBar );
			
			// import the catalogue xml and remove the file at
			// the end of the process
			imprt.importXml( null, response.getFilename(), true, new Listener() {

				@Override
				public void handleEvent(Event arg0) {
					
					// get the new catalogue version
					CatalogueDAO catDao = new CatalogueDAO();
					Catalogue newCatalogue = catDao.getCatalogue( 
							catalogue.getCode(), response.getVersion() );

					// open the new version of the catalogue
					// this also refreshes the graphics
					newCatalogue.open();
					
					// notify that the reserve started
					start.start();
					
					// reserve the new version of the catalogue
					startReserveThread ( newCatalogue, level, description, listener );
				}
			} ); 

			break;
		default:
			break;
		}
		
		return response;
	}
	
	/**
	 * Unreserve a catalogue. See {@linkplain Dcf#reserve}
	 * @param catalogue
	 * @param description
	 * @param listener
	 */
	public void unreserve ( Catalogue catalogue, 
			String description, final ReserveFinishedListener listener ) {
		startReserveThread ( catalogue, ReserveLevel.NONE, description, listener );
	}

	/**
	 * Check if we can go on with the reserve operation or not.
	 * 
	 * @param catalogue the catalogue we want to reserve
	 * @param level the reserve level we want
	 * @return {@linkplain ReserveLog} indicating what is
	 * blocking the reserve operation
	 * @throws IOException
	 * @throws TransformerException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 */
	public ReserveLog reserveCheck ( final Catalogue catalogue, 
			final ReserveLevel level ) {

		// only if we are reserving (and not unreserving)
		if ( level.isNone() ) {
			return ReserveLog.NOT_RESERVING;
		}

		String format = ".xml";
		String filename = "temp_" + catalogue.getCode();
		String input = filename + format;
		String output = filename + "_version" + format;
		
		try {
			
			// export the internal version in the file
			boolean written = exportCatalogueInternalVersion( 
					catalogue.getCode(), input );

			// if no internal version is retrieved we have
			// the last version of the catalogue
			if ( !written )
				return ReserveLog.CORRECT_VERSION;
			
			VersionFinder finder = new VersionFinder( input, output );

			// if we are minor reserving a major draft => error
			// it is a forbidden action
			if ( level.isMinor() && finder.isStatusMajor() 
					&& finder.isStatusDraft() ) {
				
				System.err.println ( "Cannot perform a reserve minor on major draft" );
				
				return ReserveLog.MINOR_FORBIDDEN;
			}

			// compare the catalogues versions
			Version intVersion = new Version ( finder.getVersion() );
			Version localVersion = catalogue.getRawVersion();
			
			// if the downloaded version is newer than the one we
			// are working with => we are using an old version
			if ( intVersion.compareTo( localVersion ) < 0 ) {

				System.err.println ( "Cannot perform reserve on old version. Downloading the new version" );
				System.err.println ( "Last internal " + finder.getVersion() + 
						" local " + catalogue.getVersion() );
				
				// set the new version as data of the enum
				ReserveLog log = ReserveLog.OLD_VERSION;
				log.setVersion( finder.getVersion() );
				log.setFilename( input );

				return log;
			} 
			else {
				
				System.out.println ( "The last internal version has a lower or equal version "
						+ "than the catalogue we are working with." );
				System.out.println ( "Last internal " + finder.getVersion() + 
						" local " + catalogue.getVersion() );
				
				// if we have the updated version
				return ReserveLog.CORRECT_VERSION;
			}

		} catch ( IOException | 
				TransformerException | 
				ParserConfigurationException | 
				SAXException e ) {
			
			e.printStackTrace();
			
			return ReserveLog.ERROR;
		}
	}

	/**
	 * Reserve a catalogue through the web service
	 * @param catalogue
	 * @param level
	 * @param description
	 * @param listener
	 */
	private void startReserveThread( Catalogue catalogue, 
			ReserveLevel level, String description, final ReserveFinishedListener listener ) {

		// save that we are reserving/unreserving
		if ( level.isMajor() || level.isMinor() )
			reserving = true;
		else
			unreserving = true;
		
		// reserve the catalogue using the dcf web service
		ReserveThread reserve = new ReserveThread( catalogue, level, description );

		reserve.addDoneListener( new ThreadFinishedListener() {

			@Override
			public void done(Thread thread) {

				// get the reserve thread
				final ReserveThread reserveThread = 
						(ReserveThread) thread;

				listener.done( reserveThread.getResponse() );
				
				unreserving = false;
				reserving = false;
			}
		});

		reserve.start();
	}
}
