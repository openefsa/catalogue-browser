package dcf_manager;

import dcf_webservice.DcfResponse;

/**
 * Listener called when a reserve operation
 * finishes. Give the dcf response as argument.
 * @author avonva
 *
 */
public interface ReserveFinishedListener {

	/**
	 * Called when a reserve operation finished.
	 * @param response the dcf response
	 */
	public void done ( DcfResponse response );
}
