package user_preferences;

public class UIPreference extends Preference {

	public static String hideDeprMain = "hideDeprMain";
	public static String hideNotReprMain = "hideNotReprMain";
	public static String hideDeprDescribe = "hideDeprDescribe";
	public static String hideNotReprDescribe = "hideNotReprDescribe";
	
	public UIPreference( String key, PreferenceType type, Object value ) {
		super(key, type, value);
	}
}
