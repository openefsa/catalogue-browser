package user_preferences;

public enum OptionType {
	TERM_TYPE,
	ATTRIBUTE
}
