package ui_implicit_facet;

/**
 * Enum to classify if a facet descriptor is implicit or explicit
 * @author avonva
 *
 */
public enum FacetType {IMPLICIT, EXPLICIT}
