import java.util.ArrayList;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.Viewer;

public class ContentProviderApplicability implements IStructuredContentProvider {

	public void dispose ( ) {}

	public void inputChanged ( Viewer arg0 , Object arg1 , Object arg2 ) {}

	public Object[] getElements ( Object applicabilities ) {
		@SuppressWarnings("unchecked")
		ArrayList< Applicability > apps = (ArrayList< Applicability >) applicabilities;
		if ( apps != null )
			return apps.toArray();
		else
			return null;
	}

}
