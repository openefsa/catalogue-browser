import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Display;

/**
 * This class is responsible for providing an image ad text for each item
 * contained in the tree viewer
 * 
 * @author
 * 
 */
public class LabelProviderTermAttributeApplicability implements ILabelProvider {

	LabelProviderTerm	_termLabelProvider;

	public LabelProviderTermAttributeApplicability() {
		try {
			_termLabelProvider = new LabelProviderTerm();
		} catch ( Exception e ) {
			e.printStackTrace();
		}
	}

	public void addListener ( ILabelProviderListener arg0 ) {
	}

	public void dispose ( ) {
	}

	public boolean isLabelProperty ( Object arg0 , String arg1 ) {
		return false;
	}

	public void removeListener ( ILabelProviderListener arg0 ) {
	}

	/**
	 * This method answers an SWT Image to be used when displaying the domain
	 * object
	 */
	public Image getImage ( Object arg0 ) {
		if ( arg0 != null ) {
			return _termLabelProvider.getImage( ( (TermElem) arg0 ).term );
		}
		return null;
	}

	/**
	 * The getText method answers a string that represents the label for the
	 * domain object, element.
	 */
	public String getText ( Object arg0 ) {

		if ( arg0 != null ) {
			return _termLabelProvider.getText( ( (TermElem) arg0 ).term );
		}
		return null;
	}

}
